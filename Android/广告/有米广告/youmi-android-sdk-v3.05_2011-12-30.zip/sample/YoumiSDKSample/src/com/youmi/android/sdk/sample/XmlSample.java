package com.youmi.android.sdk.sample;

import android.app.Activity;
import android.os.Bundle;

/**
 * XML布局示例
 * 用于使用xml布局方式嵌入广告的示例，首先需要在 res/values 文件夹下添加一个attrs.xml文件
 * 然后在xml布局中添加net.youmi.android.AdView。
 * @author 有米广告
 *
 */
public class XmlSample extends Activity {
	
	
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState); 
		setContentView(R.layout.xmlsample); 
	}
	
	
}
